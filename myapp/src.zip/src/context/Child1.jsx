import React from 'react'

const Child1 = () => {
  return (
    <div>
      <h1>Child1</h1>
    </div>
  )
}

export default Child1
