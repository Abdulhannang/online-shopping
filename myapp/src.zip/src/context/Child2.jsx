import React from 'react'

const Child2 = () => {
  return (
    <div>
      <h1>Child2</h1>
    </div>
  )
}

export default Child2
