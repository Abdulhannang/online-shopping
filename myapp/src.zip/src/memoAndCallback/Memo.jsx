import React, { useState, useMemo, useCallback } from "react";
import Child from "./Child";

const Memo = () => {
  let [add, setAdd] = useState(0);
  let [minus, setMinus] = useState(100);

  //! it returns memorized value
  let memorizedVal = useMemo(() => {
    console.log("multiply func");
    return add * 10;
  }, [add]);

  //   function multiply() {
  //     console.log("multiply func");
  //     return add * 10;
  //   }

  //! it returns memorized function
  let memorizedFunc = useCallback(() => {
    console.log("i am data func");
  }, []);
  //   function data() {
  //     console.log("i am data func");
  //   }

  return (
    <div>
      <h1>Addition {add}</h1>
      <button onClick={() => setAdd(add + 1)}>add</button>

      <h1>Minus {minus}</h1>
      <button onClick={() => setMinus(minus - 1)}>minus</button>

      <h1>Multiplication {memorizedVal}</h1>

      <Child prop={memorizedFunc} />
    </div>
  );
};

export default Memo;
