import React from "react";
import Child1 from "./Child1";

const Parent = () => {
  
  return (
    <div>
      <h1>Hoc Parent</h1>
      <Child1 />
    </div>
  );
};

export default Parent;
