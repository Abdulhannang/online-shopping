import React from 'react'
import Chidl2 from "./Chidl2"
const Child1 = () => {
  return (
    <div>
      Child 1

      <Chidl2/>
    </div>
  )
}

export default Child1
