const Fbc = () => {
  return (
    <div>
      <h1>I am Function Based Component</h1>
    </div>
  );
};

export default Fbc;
