import { Component } from "react";

class Cbc extends Component {
  render() {
    return (
      <div>
        <h1>I am Class Based Component</h1>
      </div>
    );
  }
}

export default Cbc
